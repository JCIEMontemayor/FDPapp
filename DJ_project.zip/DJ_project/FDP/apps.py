from django.apps import AppConfig


class FdpConfig(AppConfig):
    name = 'FDP'
